export class TestCase{
    testcaseid:number | undefined;
    taskId:string | undefined;
    testCycleId:number | undefined;
    testGroupId:string | undefined
    status:string | undefined;
    isCheck:boolean | undefined; 
    description: string | undefined;
    showlogBtn:boolean | undefined;
}
