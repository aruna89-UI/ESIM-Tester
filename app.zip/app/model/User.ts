export class User{
    public userId:number | undefined
	private firstName :string | undefined;
	private lastName:string | undefined;
	private userName : string | undefined;
	private password :string | undefined;
	private roleId : string | undefined;
	private emailId : string | undefined;
}