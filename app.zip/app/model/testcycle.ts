export class TestCycle{
    id:number | undefined;
    userId: number | undefined;
    name: string | undefined;
    testserver_id!: number;
    iut_profile_id: string | undefined;
    status: string | undefined;

}

export class ResultTestRun{
    
}

