export class IUTprofile{
    id:number | undefined;
    userId :number | undefined;
    profileTypeId : number | undefined;
    iutName: string | undefined;
    deviceId : string | undefined;
    specId : number | undefined;
    status : string | undefined;
    autoDelete : string | undefined;
}

export class eUICC{
    UserId : number | undefined;
		profile_type_id : number | undefined;
        IUT_RSP_VERSION: string | undefined;
        IUT_DLOA_URL: string |undefined;
        IUT_PP_VERSION: string |undefined;
        IUT_EUICC_FIRMWARE_VER: string| undefined;
        IUT_GLOBALPLATFORM_VERSION: string | undefined;
        IUT_TS102241_VERSION: string | undefined;
        IUT_EUICC_CATEGORY: string |undefined;
        IUT_PLATFORM_LABEL: string |undefined;
        IUT_SAS_ACREDITATION_NUMBER: string | undefined;
        IUT_UICC_CAPABILITY: string| undefined;
        IUT_SIMA_VERSION: string |undefined;
        iUTProfile: IUTprofile | undefined

}
