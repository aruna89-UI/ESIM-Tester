export class TestServer{
    serverId!: number;
    serverName: string | undefined;
    ipAddress: string | undefined;
    userId: number | undefined;
    description: string | undefined;
    status: string | undefined;

}

