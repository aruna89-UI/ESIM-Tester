export class Task{
    taskId: number | undefined 
    testcycle_id: number | undefined
    status: string | undefined
    user_id: number | undefined 
//    iut_profile_id: any | undefined
    specid: number|  undefined
    deviceId:string | undefined
    testIds:string | undefined;
    testGroupId:string | undefined
    date:Date | undefined

}