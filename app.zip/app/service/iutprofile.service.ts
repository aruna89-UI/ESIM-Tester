import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { eUICC } from '../model/IUTprofile';

@Injectable({
  providedIn: 'root'
})
export class IutprofileService {

  baseUrl:string = 'http://10.55.28.158:8080/';

  constructor(private http:HttpClient) { }

  getiutTypes():Observable<any>{
    return this.http.get(this.baseUrl+'IUTtypes');
  }

  getAllIutProfiles():Observable<any>{
    return this.http.get(this.baseUrl+'allprofiles');
  }

  addIUTprofile(profile:any):Observable<any>{
    return this.http.post(this.baseUrl+'profiles',profile);
  }
  
  updateIUTprofile(profile:any,id:any):Observable<any>{
    debugger;
    return this.http.put(this.baseUrl+'profiles/'+id,profile);
  }

  deleteiutProfile(id:any):Observable<any>{
    debugger;
    return this.http.delete(this.baseUrl+'profiles/'+id,id);
  }
  getallTestCycle():Observable<any>{
    return this.http.get<any>(this.baseUrl+'alltestcycles');
  }

}
