import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, tap, throwError } from 'rxjs';
import { TestCycle } from '../model/testcycle';
import { Task } from '../model/Task';
import { TestCase } from '../model/TestCase';

@Injectable({
  providedIn: 'root'
})
export class TestCycleSummaryService {

  testsimulatorUrl:string='http://10.55.28.159:8080/v1/';
  apiUrl:string='http://10.55.28.158:8080/';

  constructor(private httpClient : HttpClient) { }

  updateTestcase(testcase:any):Observable<any>{
    return this.httpClient.put<any>(this.apiUrl+'testcase/'+testcase.testcaseid,testcase)
  }
 
  updateTestCycle(cycle:TestCycle):Observable<any>{
    return this.httpClient.put<any>(this.apiUrl+'cycle/'+cycle.id,cycle);
    }

  stopCurrentRuningTask(task:Task):Observable<any>{
    debugger;
    return this.httpClient.put<any>(this.apiUrl+'stoptask/'+task.taskId,task);
  }

  getAllExistingTask():Observable<any>{
    return this.httpClient.get<any>(this.apiUrl+'getalltaskid');
  }
  
  getTestCasebyId(testcaseid:any):Observable<any>{
    return this.httpClient.get<any>(this.apiUrl+'testcase/'+testcaseid);
  }

  getAllTestCases():Observable<any>{
   

    return this.httpClient.get<any>(this.apiUrl+'alltestcase').pipe(
      tap(data => {
        // debug error here
        console.log(data);
      }),
      catchError(this.handleError)
    );
  }

  private handleError(error: any) {
    return throwError(error);
  }
  
}
