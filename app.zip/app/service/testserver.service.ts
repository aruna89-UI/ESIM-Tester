import { HttpClient } from '@angular/common/http';
import { Injectable, ɵpublishDefaultGlobalUtils } from '@angular/core';
import { Observable, tap } from 'rxjs';

import {TestServer} from 'src/app/model/testserver';

@Injectable({
  providedIn: 'root'
})
export class TestserverService {
  baseUrl:string = 'http://10.55.28.158:8080/servers/';
  apiUrl:string='http://10.55.28.158:8080/';

  constructor(private http:HttpClient) { }

  getAllTestServersByUserId(){
    return this.http.get<TestServer[]>(this.baseUrl+'getall');
  }

  getAllTestServers(user_id:any):Observable<TestServer[]>{
    debugger;
    return this.http.get<TestServer[]>(this.baseUrl+user_id);
  }

  addTestserver(testServer:TestServer):Observable<any>{
    debugger;
    return this.http.post(this.baseUrl,testServer,{responseType: 'text' as 'json'});
  }

  updateTestserver(testServer:any,userid:number):Observable<any>{
    debugger;
    return this.http.put<any>(this.baseUrl +userid+'/'+testServer.serverId ,testServer);
  }

  deleteTestserver(serverid:number):Observable<any>{
    debugger;
    return this.http.delete(this.baseUrl+serverid);
  }

  getServerHealthcheck(ipAddress:any):Observable<any>{
    debugger;
    return this.http.get(`http://${ipAddress}:8080/v1/health`);
  }

  getallTestCycle():Observable<any>{
    return this.http.get<any>(this.apiUrl+'alltestcycles');
  }
}
