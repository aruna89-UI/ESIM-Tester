import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { map, Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {


  constructor(private http:HttpClient,private router: Router) {}

  

  loginUser(loginObj:any): Observable<any>{
    debugger;
    
    return this.http.post<any>('http://10.55.28.158:8080/login', 
    loginObj).pipe(
      tap(data =>{
        localStorage.setItem('loggedUser', data.userName);
        localStorage.setItem('loggedUserId', data.userId);
         //console.log('All: ', this.username)
      }
      )
      );
  }

  logout(){
localStorage.removeItem("loggedUser");
localStorage.removeItem('loggedUserId');
localStorage.removeItem('token');
      this.router.navigate(['login']);
  }

  // get currentUserId(){
  //   return this.userId.asob
  // }

}