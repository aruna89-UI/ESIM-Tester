import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, tap, throwError } from 'rxjs';
import { TestCycle } from '../model/testcycle';
import { Task } from '../model/Task';
import { TestCase } from '../model/TestCase';

@Injectable({
  providedIn: 'root'
})
export class TestCycleService {
  testsimulatorUrl:string='http://10.55.28.159:8080/v1/';
  apiUrl:string='http://10.55.28.158:8080/';
  
  constructor(private httpClient : HttpClient) { 

  }

  getIUTprofile():Observable<any>{
    return this.httpClient.get(this.apiUrl+'allprofiles');
  }

  getAllTestGroups():Observable<any>{
    // working
    return this.httpClient.get(this.testsimulatorUrl+'spec/0/testGroup').pipe(
      tap(data => {
        // debug error here
        console.log(data);
      }),
      catchError(this.handleError)
    );
  }

  //get testcycle by ID
 getTestcyclebyId(id:number):Observable<any>{
  return this.httpClient.get<any>(this.apiUrl+'cycle/'+id).pipe(
    tap(data => {
      // debug error here
      console.log(data);
    }),
    catchError(this.handleError)
  );
 }

 //get testserver by id
 getTestServerbyId(serverId:number):Observable<any>{
  return this.httpClient.get<any>(this.apiUrl+"servers/"+serverId).pipe(
    tap(data => {
      // debug error here
      console.log(data);
    }),
    catchError(this.handleError)
  );
 }


getTestCases(id:any):Observable<any>{
  //not working as expected
return this.httpClient.get(this.testsimulatorUrl+'spec/0/testGroup/'+id+'/test')
}

getTestcaseUserbackend():Observable<any>{
  return this.httpClient.get(this.apiUrl+'alltestcase').pipe(
    tap(data => {
      // debug error here
      console.log(data);
    }),
    catchError(this.handleError)
  );
}

getTesCaseLogs(id:any):Observable<any[]>{ 
  //not working as expected
  return this.httpClient.get<any[]>(this.testsimulatorUrl+'task/'+id+'/log');
}

getAllTask():Observable<any[]>{
  // working
  return this.httpClient.get<any[]>(this.testsimulatorUrl+'task');
}

getTask(taskId:any):Observable<any[]>{
  //not working as expected
  return this.httpClient.get<any[]>(this.testsimulatorUrl+'task/'+taskId);
}

runeUICCtest(IUTProfile:any):Observable<any>{
  return this.httpClient.post<any>(this.testsimulatorUrl+'runtask',IUTProfile);
}

addTestCycle(testCycle:TestCycle):Observable<any>{
  return this.httpClient.post<any>(this.apiUrl+'addtestcycle', testCycle);
}

getallTestCycle():Observable<any>{
  return this.httpClient.get<any>(this.apiUrl+'alltestcycles');
}

getAllExistingTask():Observable<any>{
  return this.httpClient.get<any>(this.apiUrl+'getalltaskid');
}

addTask(task:Task):Observable<any>{
  return this.httpClient.post<any>(this.apiUrl+'addtaskid',task);
}
//task/267/result"
getTestcaseResult(taskid:any):Observable<any>{
  return this.httpClient.get<any>(this.testsimulatorUrl+'task/'+taskid+'/result')
}

stopCurrentRuningTask(task:Task):Observable<any>{
  return this.httpClient.put<any>(this.apiUrl+'stoptask/'+task.taskId,task);
}

markTestCycleComplete(cycle:TestCycle):Observable<any>{
return this.httpClient.put<any>(this.apiUrl+'cycle/'+cycle.id,cycle);
}

//addTestcases
saveTestCases(testCase:TestCase):Observable<any>{
  return this.httpClient.post<any>(this.apiUrl+'testcase',testCase)
}

updateTestcase(testcase:any):Observable<any>{
  return this.httpClient.put<any>(this.apiUrl+'testcase/'+testcase.testcaseid,testcase)
}

private handleError(error: any) {
  return throwError(error);
}

}
