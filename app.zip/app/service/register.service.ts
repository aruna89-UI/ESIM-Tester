import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../model/User';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  apiUrl:string='http://10.55.28.158:8080/';

  constructor(private http:HttpClient) { }

  register(user:any):Observable<any> {
    return this.http.post(this.apiUrl+'registeruser', user);
  }
}
