import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TestReportService {
  testsimulatorUrl:string='http://10.55.28.159:8080/v1/';
  apiUrl:string='http://10.55.28.158:8080/';

  constructor(private httpClient : HttpClient) { }

  getAllExcutedTask():Observable<any>{
    return this.httpClient.get<any>(this.apiUrl+'getalltaskid');
  }
  getallTestCycle():Observable<any>{
    return this.httpClient.get<any>(this.apiUrl+'alltestcycles');
  }

  deleteTestCycle(id:any):Observable<any>{
    return this.httpClient.delete<any>(this.apiUrl+'cycle/'+id)
  }
}
