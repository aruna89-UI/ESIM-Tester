import { TestBed } from '@angular/core/testing';

import { CurrentRunningTaskService } from './current-running-task.service';

describe('CurrentRunningTaskService', () => {
  let service: CurrentRunningTaskService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CurrentRunningTaskService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
