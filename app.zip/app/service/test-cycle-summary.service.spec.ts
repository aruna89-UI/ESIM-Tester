import { TestBed } from '@angular/core/testing';

import { TestCycleSummaryService } from './test-cycle-summary.service';

describe('TestCycleSummaryService', () => {
  let service: TestCycleSummaryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TestCycleSummaryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
