import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, tap, throwError } from 'rxjs';
import { TestCycle } from '../model/testcycle';
import { Task } from '../model/Task';
import { TestCase } from '../model/TestCase';

@Injectable({
  providedIn: 'root'
})
export class TestcaseService {
  testsimulatorUrl:string='http://10.55.28.159:8080/v1/';
  apiUrl:string='http://10.55.28.158:8080/';

  constructor(private httpClient : HttpClient) { }

  getTestCases(id:any):Observable<any>{
  return this.httpClient.get(this.testsimulatorUrl+'spec/0/testGroup/'+id+'/test')
  }

  //addTestcases
saveTestCases(testCase:TestCase):Observable<any>{
  return this.httpClient.post<any>(this.apiUrl+'testcase',testCase)
}

getTestcaseUserbackend():Observable<any>{
  return this.httpClient.get(this.apiUrl+'alltestcase').pipe(
    tap(data => {
      // debug error here
      console.log(data);
    }),
    catchError(this.handleError)
  );
}
getAllExistingTask():Observable<any>{
  return this.httpClient.get<any>(this.apiUrl+'getalltaskid');
}
getTesCaseLogs(id:any):Observable<any[]>{ 
  return this.httpClient.get<any[]>(this.testsimulatorUrl+'task/'+id+'/log');
}

addTask(task:Task):Observable<any>{
  return this.httpClient.post<any>(this.apiUrl+'addtaskid',task);
}
runeUICCtest(IUTProfile:any):Observable<any>{
  return this.httpClient.post<any>(this.testsimulatorUrl+'runtask',IUTProfile);
}

getTestcaseResult(taskid:any):Observable<any>{
  return this.httpClient.get<any>(this.testsimulatorUrl+'task/'+taskid+'/result')
}

updateTestcase(testcase:any):Observable<any>{
  return this.httpClient.put<any>(this.apiUrl+'testcase/'+testcase.testcaseid,testcase)
}

getTestcasebyId(testId:any):Observable<any>{
  return this.httpClient.get<any>(this.apiUrl+'testcase/'+testId)
  
}

private handleError(error: any) {
  return throwError(error);
}

}
