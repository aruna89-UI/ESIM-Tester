import { TestBed } from '@angular/core/testing';

import { IutprofileService } from './iutprofile.service';

describe('IutprofileService', () => {
  let service: IutprofileService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IutprofileService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
