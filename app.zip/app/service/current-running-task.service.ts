import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, tap, throwError } from 'rxjs';
import { TestCycle } from '../model/testcycle';
import { Task } from '../model/Task';
import { TestCase } from '../model/TestCase';

@Injectable({
  providedIn: 'root'
})
export class CurrentRunningTaskService {

  testsimulatorUrl:string='http://10.55.28.159:8080/v1/';
  apiUrl:string='http://10.55.28.158:8080/';

  constructor(private httpClient : HttpClient) { }

  updateTestcase(testcase:any):Observable<any>{
    return this.httpClient.put<any>(this.apiUrl+'testcase/'+testcase.testcaseid,testcase)
  }


  stopCurrentRuningTask(task:Task):Observable<any>{
    return this.httpClient.put<any>(this.apiUrl+'stoptask/'+task.taskId,task);
  }

  getAllExistingTask():Observable<any>{
    return this.httpClient.get<any>(this.apiUrl+'getalltaskid');
  }
  
  getTestCasebyId(testcaseid:any):Observable<any>{
    return this.httpClient.get<any>(this.apiUrl+'testcase/'+testcaseid);
  }
}
