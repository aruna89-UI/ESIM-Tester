import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  constructor(private http:HttpClient) {}
  loginUser(loginObj:any): Observable<any>{
    return this.http.get('http://10.55.28.158:8080/login',loginObj)
  }

}