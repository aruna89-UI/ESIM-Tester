import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
//import { ComponentComponent } from './component/component.component';
//import { LayoutComponent } from './layout/layout.component';
//import { HeaderComponent } from './header/header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './Layout/login/login.component';
import { HomeComponent } from './Components/home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { HeaderComponent } from './Layout/header/header.component';
import { IUTprofileComponent } from './Components/iutprofile/iutprofile.component';
import { TestServerComponent } from './Components/test-server/test-server.component';
import { TestReportComponent } from './Components/test-report/test-report.component';
import { TestCycleComponent } from './Components/test-cycle/test-cycle.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NewtestcycleComponent } from './Components/newtestcycle/newtestcycle.component';
import { NgxPaginationModule } from 'ngx-pagination';
//import { HomeComponent } from './Layout/home/home.component';
//import { FontAwesomeModule } from ..//angular-fontawesome';
import {MultiSelectModule} from 'primeng/multiselect';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { RegisterComponent } from './Components/register/register.component';
import { RegistersuccessComponent } from './Components/registersuccess/registersuccess.component';
import { TestcyclesummaryComponent } from './Components/testcyclesummary/testcyclesummary.component';
import { CurrentRunningTaskComponent } from './Components/current-running-task/current-running-task.component';
import { TestcasetableComponent } from './Components/testcasetable/testcasetable.component';

@NgModule({
  declarations: [
    AppComponent,
    //ComponentComponent,
    LoginComponent,
    HomeComponent,
    HeaderComponent,
    IUTprofileComponent,
    TestServerComponent,
    TestReportComponent,
    TestCycleComponent,
    NewtestcycleComponent,
    RegisterComponent,
    RegistersuccessComponent,
    TestcyclesummaryComponent,
    CurrentRunningTaskComponent,
    TestcasetableComponent,
   // LayoutComponent,
  //  HeaderComponent,
  
   // HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    NgbModule,
    ReactiveFormsModule,
    FormsModule,
    NgxPaginationModule,
    MultiSelectModule,
    BrowserAnimationsModule
    //FontAwesomeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
