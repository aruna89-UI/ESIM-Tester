import { Component, OnInit } from '@angular/core';
import { TestCycleService } from 'src/app/service/test-cycle.service';
import { TestCase } from 'src/app/model/TestCase';
import { IutprofileService } from 'src/app/service/iutprofile.service';
import { eUICC } from 'src/app/model/IUTprofile';
import { Task } from 'src/app/model/Task';
import { ActivatedRoute } from '@angular/router';
import { ThisReceiver } from '@angular/compiler';
import { TestCycle } from 'src/app/model/testcycle';
import { TestserverService } from 'src/app/service/testserver.service';
import { TestServerComponent } from '../test-server/test-server.component';
import { TestServer } from 'src/app/model/testserver';
import { Subscription, switchMap, timer } from 'rxjs';
import { group } from '@angular/animations';

@Component({
  selector: 'app-newtestcycle',
  templateUrl: './newtestcycle.component.html',
  styleUrls: ['./newtestcycle.component.css']
})
export class NewtestcycleComponent implements OnInit {
  page: number = 1;
  totalLength: any;
  loggedUserId: any;
  testCycleId: number;
  showModal: boolean = false;
  title: string = '';
  content: any[] = [];
  shoCurrentRunnigTask: boolean = false;
  showtestcaseTable: boolean = false;
  testCasesList: any[] = [];
  testServerId: number | undefined;
  testcycle: any;
  testServer: TestServer = new TestServer;
  iutProfilesList: any;
  selectedProfileList: any;
  profileSelected: eUICC = new eUICC;
  profilesTorun: eUICC[] = new Array;
  testGroups: any[] = [];
  groupSelected: any;
  testCases: any;
  selectedTestCases: any[] = [];
  masterSelected: any;
  disableRunbtn: boolean = false;
  runTestCaseResult: any;
  task: Task = new Task;
  date: Date = new Date();
  excutedTask: any;
  currentRunningTask: any;
  excutedTaskbyCycle: any;
  showCurrentRunnigTask: boolean = false;
  runnnigTestCases: any;
  subscription !: Subscription;



  constructor(private testCycleservice: TestCycleService, private iutservice: IutprofileService,
    private activateroute: ActivatedRoute, private testServerService: TestserverService) {
     
    this.loggedUserId = localStorage.getItem('loggedUserId');
     
    this.testCycleId = Number(this.activateroute.snapshot.paramMap.get('id'));

  }

  ngOnInit() {
    //getting all test groups
    this.getTestgroups();
        this.getTestCycle(this.testCycleId);
        this.getProfileServer();
        

//periodically checking status of task and testcases and updating to DB
// this.subscription = timer(0, 50000).pipe(
//   switchMap(async () => this.periodicCheck())).subscribe(data =>{
//     console.log("periodic check of testcase and task result:",data);
//   })

  }

  getTestCycle(cycleid:any){
    this.testCycleservice.getTestcyclebyId(this.testCycleId).subscribe((data)=>{
      this.testcycle = data[0];
         console.log("testcycle object pass to child:",data)
      });
  }


  getTestgroups(){
    this.testCycleservice.getAllTestGroups().subscribe(
      (data) => { this.testGroups = data;
        console.log(`all test groups:`, this.testGroups);
       });
  }

  cyclestatusChangeHandler(test:any){
this.testcycle=test;
console.log("testcycle status change event emiter from child to parent:",this.testcycle);
  }

  testgroupselectevent(groupid:any){
    this.groupSelected=groupid;
    console.log("groupid from testcasetable component",this.groupSelected);
  }

  onProfileSelected(profile: eUICC) {
     
    this.profilesTorun.push(profile);
  }
  
  //get iutprofile and testserver
  getProfileServer(){
  this.testCycleservice.getTestcyclebyId(this.testCycleId).subscribe(
      (data) => { this.testcycle = Object.assign({}, ...data);
      console.log("list of testcasess", this.testcycle); 
        this.testCycleservice.getTestServerbyId(this.testcycle.testserver_id).subscribe(
          (data) => { this.testServer = Object.assign({}, ...data);
          console.log("test server ip address", this.testServer); }
        );

        // get iut profile
        this.iutservice.getAllIutProfiles().subscribe(data => {
          this.iutProfilesList = data.filter((x: { userId: any; }) => x.userId == this.loggedUserId);
          this.selectedProfileList = this.iutProfilesList.filter((x: { id: string | undefined; }) => x.id == this.testcycle.iut_profile_id);
          console.log("all iut profiles:", this.selectedProfileList);
          this.profileSelected = this.selectedProfileList[0];
          this.onProfileSelected(this.profileSelected);
        });
      })
    }


  //get test cases
  onTestGroupSelected(id: any) {
    this.groupSelected =id;
    
  }

  getTestCaseId(e: any, id: string) {
    if (e.target.checked) {
      this.selectedTestCases.push(id);
    }
    else {
      this.selectedTestCases = this.selectedTestCases.filter(x => x != id)
    }
    console.log("selected testcases : ", this.selectedTestCases);
  }

  bulk() {
     
    this.selectedTestCases = [];
    for (let i = 0; i < this.testCasesList.length; i++) {
      this.testCasesList[i].isCheck = this.masterSelected
    }
  }

  periodicCheck(){
    this.testCycleservice.getTestcaseUserbackend().subscribe(
      (result)=> {
         
        this.testCasesList = result.filter((x:any)=> x.testCycleId == this.testCycleId);
        this.testCasesList.forEach(x=>{
          if(x.taskId !== '' || x.taskId !== null){
          this.testCycleservice.getTestcaseResult(x.taskId).subscribe(res =>{
             if(x.testcaseid == res[0].testid){
              x.status = res[0].executionstatus;
              x.testcaseid=res[0].testid;
              if(res[0].executionstatus != null){
                x.showlog = true;
                x.isCheck=true;
              }
             }
             this.testCycleservice.updateTestcase(x).subscribe(updateres =>{
              console.log("update status of testcase:",updateres);
             })
            })
          }
          });
          this.testCasesList.forEach(x=>{
             
            if(x.taskId !=='' || x.taskId !== null){
            this.testCycleservice.getTask(x.taskId).subscribe(
              (data)=>{
                if(data != null){
                if(x.taskId == data[0].id){
                this.task.taskId = data[0].id
                this.task.deviceId=data[0].deviceId;
                this.task.specid=data[0].specId;
                this.task.status=data[0].state;
                this.task.testIds=data[0].testIds;
                this.testCycleservice.stopCurrentRuningTask(this.task).subscribe(data =>{
                  console.log("update task:",data);
                })
              }
            }
              }
            )
            }
          });
          this.testCycleservice.getTestCases(this.groupSelected).subscribe(data =>{
            this.testCasesList = data;
          })
  })
}

}
