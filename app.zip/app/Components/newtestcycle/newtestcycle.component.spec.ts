import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewtestcycleComponent } from './newtestcycle.component';

describe('NewtestcycleComponent', () => {
  let component: NewtestcycleComponent;
  let fixture: ComponentFixture<NewtestcycleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewtestcycleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NewtestcycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
