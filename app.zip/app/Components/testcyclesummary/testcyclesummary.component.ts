import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { TestCycle } from 'src/app/model/testcycle';
import { TestCycleSummaryService } from 'src/app/service/test-cycle-summary.service';

@Component({
  selector: 'app-testcyclesummary',
  templateUrl: './testcyclesummary.component.html',
  styleUrls: ['./testcyclesummary.component.css']
})
export class TestcyclesummaryComponent implements OnInit, OnChanges {
  //@Input() testcycle: TestCycle = new TestCycle;
  @Output() cycleStatusChage: EventEmitter<any> = new EventEmitter();
  @Input() testcycle: any;
  @Input() testcycledata: any;
  allTestCases: any;
  excutedTaskbyCycle: any;
  currentRunningTask: any;
  noOfExcutedTest: number = 0;
  noOfInprogressTest: number = 0;
  noOfPassTest: number = 0;
  noOffailTest: number = 0;
  testcycleid: any;
  testcycleStatus: any;
  //testcyclefrmparent=this.testcycle;

  constructor(private testcycleSummaryService: TestCycleSummaryService) {

  }

  ngOnInit() {

  }

  ngOnChanges() {
    console.log("testcycle object frrom parent to child:", this.testcycledata);
    if (this.testcycledata != undefined) {
      if (this.testcycledata != null) {
        this.testcycleid = this.testcycledata.id;
        this.testcycleStatus = this.testcycledata.status
        this.getAllTestCases(this.testcycle);

      }
    }
  }

  markTestCycleComplete(testcycle: TestCycle, text: any) {

    testcycle.status = 'Complete';
    this.updateTestCycle(testcycle);
    this.getCurrentrunningTask(testcycle, text);
    this.cycleStatusChage.emit(this.testcycle);
  }

  //reset task, testcycle and testcase status
  resetTestCycle(testcycle: TestCycle, text: any) {
    //reset task
    testcycle.status = '';
    this.updateTestCycle(testcycle);
    //update task status
    this.getCurrentrunningTask(testcycle, text);
    //update testcase status
    this.getAllTestCases(testcycle);

  }

  getAllTestCases(testcycle: TestCycle) {

    this.testcycleSummaryService.getAllTestCases().subscribe(data => {
      console.log("get all testcases testcycle summary need to check undefined:", data);
      if (data != null || data != undefined) {
        let temp = data;
        this.allTestCases = temp.filter((x: { testCycleId: any; }) => x.testCycleId == testcycle.id);
        this.allTestCases.forEach((element: { status: null; }) => {
          element.status = null;
          this.updateTestCase(element);
        });
        this.noOfexcutedTestcaseCount(this.allTestCases);
      }
      console.log("get all testcases testcycle summary", this.allTestCases);
    })

  }

  noOfexcutedTestcaseCount(allTestCases: any) {

    this.noOfExcutedTest = allTestCases.filter((x: { status: string | null; }) => (x.status != '' || x.status != null)).length;
    this.noOfInprogressTest = allTestCases.filter((x: { status: string | null; }) => (x.status == 'inprogress' || x.status == "INCONCLUSIVE")).length;
    this.noOfPassTest = allTestCases.filter((x: { status: string | null; }) => (x.status == 'pass')).length;
    this.noOffailTest = allTestCases.filter((x: { status: string | null; }) => (x.status == 'fail')).length;
    console.log("no of excuted testcase length", this.noOfExcutedTest);
    console.log("no of inprogress testcase length", this.noOfInprogressTest);
    console.log("no of pass testcase length", this.noOfPassTest);
    console.log("no of fail testcase length", this.noOffailTest);
  }

  //Check if any running Task
  getCurrentrunningTask(testcycle: any, text: any) {
    this.testcycleSummaryService.getAllExistingTask().subscribe(data => {
      //this.excutedTask = data.filter((x: { user_id: any; }) => x.user_id == this.loggedUserId);
      this.excutedTaskbyCycle = data.filter((x: { testcycleId: number; }) => x.testcycleId == this.testcycle.id)
      if (text = "Complete") {
        this.currentRunningTask = this.excutedTaskbyCycle.filter((x: any) => x.status == 'inprogress');
      }
      if (text = 'reset') {
        this.currentRunningTask = this.excutedTaskbyCycle;
      }
      console.log("existing task list", this.currentRunningTask);
      if (this.currentRunningTask != undefined) {
        if (this.currentRunningTask.length != 0) {
          if (confirm("Want to stop Current running task") == true) {
            this.currentRunningTask[0].status = testcycle.status;
            this.updateTask(this.currentRunningTask[0]);
          } else {
            return;
          }
        }
      }
    }
    );
  }

  //update Task status
  updateTask(task: any) {

    this.testcycleSummaryService.stopCurrentRuningTask(task).subscribe((data: any
    ) => console.log("update task:", data))
  };

  //update Testcycle status
  updateTestCycle(testcycle: any) {
    this.testcycleSummaryService.updateTestCycle(testcycle).subscribe(data => {
      console.log("update testcycle:", data);
    })
  }

  //update testcases
  updateTestCase(testcase: any) {
    this.testcycleSummaryService.updateTestcase(testcase).subscribe(
      data => { console.log("update testcase result", data) }
    )
  }
}
