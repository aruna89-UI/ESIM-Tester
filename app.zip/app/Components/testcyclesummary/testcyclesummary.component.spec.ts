import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestcyclesummaryComponent } from './testcyclesummary.component';

describe('TestcyclesummaryComponent', () => {
  let component: TestcyclesummaryComponent;
  let fixture: ComponentFixture<TestcyclesummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestcyclesummaryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestcyclesummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
