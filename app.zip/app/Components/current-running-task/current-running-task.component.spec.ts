import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentRunningTaskComponent } from './current-running-task.component';

describe('CurrentRunningTaskComponent', () => {
  let component: CurrentRunningTaskComponent;
  let fixture: ComponentFixture<CurrentRunningTaskComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CurrentRunningTaskComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CurrentRunningTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
