import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { CurrentRunningTaskService } from 'src/app/service/current-running-task.service';
import { TestCycleService } from 'src/app/service/test-cycle.service';

@Component({
  selector: 'app-current-running-task',
  templateUrl: './current-running-task.component.html',
  styleUrls: ['./current-running-task.component.css']
})
export class CurrentRunningTaskComponent implements OnInit, OnChanges {
  @Input() testcycle: any;
  excutedTask: any;
  currentRunningTask: any;
  excutedTaskbyCycle: any;
  loggedUserId: any;
  showCurrentRunnigTask: boolean = false;
  testCase: any;

  constructor(private currentRunningTaskService: CurrentRunningTaskService) {


  }

  ngOnInit(): void {
  }

  ngOnChanges() {
    console.log("testcycle object frrom parent to child:", this.testcycle);
    if (this.testcycle != undefined) {
      if (this.testcycle != null) {
        this.getCurrentrunningTask(this.testcycle);
      }
    }
  }


  stopTask(task: any) {
    debugger;
    task.status = "";
    this.updateTask(task);
    this.getTestcasebyId(task.testIds);
    if (this.testCase != null || this.testCase != undefined) {
      this.testCase.status = null;
      this.updateTestCase(this.testCase);
    }

  }

  //Check if any running Task
  getCurrentrunningTask(testcycle: any) {
    this.currentRunningTaskService.getAllExistingTask().subscribe(data => {
      debugger;
      this.excutedTaskbyCycle = data.filter((x: { testcycleId: number; }) => x.testcycleId == this.testcycle.id)
      this.currentRunningTask = this.excutedTaskbyCycle.filter((x: any) => x.status == 'inprogress');
      console.log("existing task list", this.currentRunningTask);
      debugger;
      if (this.currentRunningTask.length != 0) {
        this.showCurrentRunnigTask = true;
      }
    });
  }

  //update testcsase status
  updateTestCase(testcase: any) {
    this.currentRunningTaskService.updateTestcase(testcase).subscribe(
      data => { console.log("update testcase result", data) }
    )
  }

  //update Task status
  updateTask(task: any) {
    debugger;
    this.currentRunningTaskService.stopCurrentRuningTask(task).subscribe((data: any
    ) => console.log("update task:", data))
  };

  //get testcase by id
  getTestcasebyId(testcaseid: any) {
    debugger;
    this.currentRunningTaskService.getTestCasebyId(testcaseid).subscribe(data => {
      this.testCase = Object.assign({}, ...data);
      console.log("testcase result:", data)
    })
  }
}
