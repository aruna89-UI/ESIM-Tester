import { HttpClient } from '@angular/common/http';
import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { TestserverService } from 'src/app/service/testserver.service';
import { UserService } from 'src/app/service/user.service';

import { TestServer } from 'src/app/model/testserver';
import { NavigationExtras, Router } from '@angular/router';
import { Subscription, switchMap, timer } from 'rxjs';

@Component({
  selector: 'app-test-server',
  templateUrl: './test-server.component.html',
  styleUrls: ['./test-server.component.css']
})
export class TestServerComponent implements OnInit {

  serverList: any;
  submitted: boolean = true;
  loggedUserId: any;
  testServer: TestServer = new TestServer();
  editserver: TestServer[] = [];
  isAvailable: string = '';
  subscription !: Subscription;
  testCycleList: any;

  constructor(private http: HttpClient, private testserverService: TestserverService, private userService: UserService, private router: Router) {
    debugger;
    this.loggedUserId = localStorage.getItem('loggedUserId');
    console.log("loggeduser id", this.loggedUserId);
    //  this.testserverService.getAllTestServers(this.loggedUserId).subscribe(data =>
    //   this.serverList = data
    //   );

    // this.testserverService.getAllTestServersByUserId().subscribe(data =>{
    // this.serverList = data.filter(x=> x.userId == this.loggedUserId);
    // console.log("server list:" , this.serverList);
    // });

    // this.testserverService.getServerHealthcheck().subscribe(data =>{
    //   console.log("server check", data);
    // })

  }

  ngOnInit() {
    debugger;
    this.subscription = timer(0, 50000).pipe(
      switchMap(() => this.testserverService.getAllTestServersByUserId())
    ).subscribe(result => {
      this.serverList = result.filter(x => x.userId == this.loggedUserId);
      console.log(result);
      this.serverList.forEach((x: any) => {
        this.testserverService.getServerHealthcheck(x.ipAddress).subscribe((data) => {
          debugger;
          if (data != null) {
            this.isAvailable = "Available";
            this.testServer.status = this.isAvailable;
            // this.testServer.status = "Available"
          }
          else {
            this.isAvailable = "Unavailable";
            this.testServer.status = this.isAvailable;
            // this.testServer.status = "Busy"
          }
          console.log("server health check - is available:", this.isAvailable);

        })
      });
      debugger;
      this.serverList.forEach((x: {
        status: string; serverId: any;
      }) => {
        debugger;
        this.testserverService.getallTestCycle().subscribe(
          (data) => {
            this.testCycleList = data.filter((i: any) => i.testserver_id == x.serverId);
            if (this.testCycleList.length != 0) {
              // this.isAvailable = "Available";
              x.status = "Busy";
            }
            else {
              this.testServer.status = "Available";
            }
            console.log("testcycle based on test serverid status", this.testServer.status, this.serverList);
            this.testserverService.updateTestserver(x, this.loggedUserId).subscribe(data => {
              console.log("update testserver result:", data);
            })
          }
        );
        

      })
    }
    );
  }

  add() {
    debugger;
    this.testServer.userId = this.loggedUserId;
    this.testserverService.addTestserver(this.testServer).subscribe(
      data => {
        console.log("addng testserver:", JSON.parse(data)),
        alert(data);
      }
    );
    this.testServer = new TestServer();
    this.closeModel();
    window.location.reload();

  }

  openModel() {
    const model = document.getElementById("myModal");
    if (model != null) {
      model.style.display = "block";
      this.testServer = new TestServer();
    }

  }
  closeModel() {
    const model = document.getElementById("myModal");
    if (model != null) {
      model.style.display = "none";
    }
  }

  openEditModel(id: number) {
    debugger;
    const model = document.getElementById("editModal");
    if (model != null) {
      model.style.display = "block";
    }
    this.testServer = this.serverList.filter((x: { serverId: number; }) => x.serverId == id)[0];
    console.log("edit server details population data", this.testServer);

  }

  closeEditModel() {
    const model = document.getElementById("editModal");
    if (model != null) {
      model.style.display = "none";
    }
  }
  openTestCycle(server: TestServer) {
    debugger;
    let navigationExtras: NavigationExtras = {
      queryParams: {
        severName: server.serverName,
        serverIPaddress: server.ipAddress
      }
    }
    console.log("datafrom routing:", navigationExtras);
    this.router.navigate(['/testcycle', server.serverId]);
    // this.router.navigate(['/testcycle',navigationExtras]);
  }
  updateServer() {
    debugger;
    this.submitted = false;
    this.testserverService.updateTestserver(this.testServer, this.loggedUserId).subscribe(
      data => console.log("update server response", data)
    )
    this.closeEditModel();
  }

  onUpdate() {
    this.submitted = true;
  }

  deleteServer(id: number) {
    debugger;
    this.testserverService.deleteTestserver(id).subscribe(data => {
      console.log("delete server:", data);

      this.serverList = this.testserverService.getAllTestServers(this.loggedUserId);
      alert(data);
    });
    window.location.reload();
  }

  sendit(inputValue: any) {
    debugger;
    console.log(inputValue);
    this.testserverService.getServerHealthcheck(inputValue).subscribe((data) => {
      debugger;
      if (data != null) {
        this.isAvailable = "Available";
        this.testServer.status = this.isAvailable;
        // this.testServer.status = "Available"
      }
      else {
        this.isAvailable = "Unavailable";
        this.testServer.status = this.isAvailable;
        // this.testServer.status = "Busy"
      }
      console.log("server health check - is available:", this.isAvailable);

    })
  };

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
