import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TestServer } from 'src/app/model/testserver';
import { IutprofileService } from 'src/app/service/iutprofile.service';
import { TestCycleService } from 'src/app/service/test-cycle.service';
import { TestReportService } from 'src/app/service/testreport.service';
import { TestserverService } from 'src/app/service/testserver.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  loggedUserId:any;
  testServer:TestServer[]=[];
  iutProfiles:any;
  taskReport:any;
  excutedTask:any;

  constructor(private router: Router,
    private testserverService:TestserverService,
    private userService:UserService,
    private iutService : IutprofileService,
    private testReportService : TestReportService,
    private testCycleservice:TestCycleService
    ) { 

    this.loggedUserId = localStorage.getItem('loggedUserId');
   this.testserverService.getAllTestServersByUserId().subscribe(data =>{
    this.testServer = data.filter(x=> x.userId == this.loggedUserId);
    console.log("testserver list:", this.testServer);
   }
    );

    this.iutService.getAllIutProfiles().subscribe(data =>{
      this.iutProfiles = data.filter((x: { userId: any; })=> x.userId == this.loggedUserId);
    });

    this.testReportService.getAllExcutedTask().subscribe(data =>{
      this.taskReport= data;
      console.log("task report",data);
    });

    this.testCycleservice.getAllExistingTask().subscribe(data =>{
      this.excutedTask = data;
      console.log("executedTask",this.excutedTask);
    })
  }

  ngOnInit(): void {
  }

  gotoTestReport() {
    this.router.navigate(['/testreport']);
  }

  gotoIUTProfile(){
    this.router.navigate(['/IUTProfile']);
  }

  gotoTestServer(){
    this.router.navigate(['/testserver']);
  }
  goToTestCycle(){
    this.router.navigate(['/testcycle']);

  }
  gotoDetailTestcycle(){
    this.router.navigate(['/newtestcycle']);
  }


}
