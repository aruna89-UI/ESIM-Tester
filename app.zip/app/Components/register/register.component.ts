import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RegisterService } from 'src/app/service/register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup | any;
    submitted = false;
 
    constructor(private formBuilder: FormBuilder, private router:Router,
                 private registerService : RegisterService) { }
 
    ngOnInit() {
        this.registerForm = this.formBuilder.group({
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            userName:['', Validators.required],
            emailId: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required, Validators.minLength(6)]]
        });
    }
 
    onSubmit() {
        this.submitted = true;
        debugger;
        this.registerService.register(this.registerForm.value).subscribe(item=>{
               
        })
        // stop the process here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }
 
        //alert('SUCCESS!!');
        this.router.navigate(['./registersuccesful'])
    }

    login(){
        this.router.navigate(['./login'])
    }

}

