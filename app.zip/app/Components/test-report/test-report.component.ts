import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TestReportService } from 'src/app/service/testreport.service';

@Component({
  selector: 'app-test-report',
  templateUrl: './test-report.component.html',
  styleUrls: ['./test-report.component.css']
})
export class TestReportComponent implements OnInit {
  taskReport:any;
  loggedUserId:any;

  constructor(private testReportService:TestReportService,private router :Router) { 
    this.loggedUserId = localStorage.getItem('loggedUserId');
 this.testReportService.getallTestCycle().subscribe(data =>{
  this.taskReport= data.filter((x: { userId: any; })=>x.userId == this.loggedUserId);
  console.log("task report",this.taskReport);
});
  }

  ngOnInit(): void {
  }

   
  dateshow(){
     
  }
  goToDetailTestCycle(id:any){

    this.router.navigate(['./newtestcycle',id]);
  }
  deleteTestCycle(testCycleId:any){
this.testReportService.deleteTestCycle(testCycleId).subscribe(res =>{
  console.log("delete response", res)
})
  }


}
