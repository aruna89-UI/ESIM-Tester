import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestCycleComponent } from './test-cycle.component';

describe('TestCycleComponent', () => {
  let component: TestCycleComponent;
  let fixture: ComponentFixture<TestCycleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestCycleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestCycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
