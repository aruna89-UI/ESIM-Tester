import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators,FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TestCycle } from 'src/app/model/testcycle';
import { TestServer } from 'src/app/model/testserver';
import { TestCycleService } from 'src/app/service/test-cycle.service';
import { TestserverService } from 'src/app/service/testserver.service';

@Component({
  selector: 'app-test-cycle',
  templateUrl: './test-cycle.component.html',
  styleUrls: ['./test-cycle.component.css']
})
export class TestCycleComponent implements OnInit {
  [x: string]: any;
  cities: any[]=[];
  form!: FormGroup;
  loggedUserId:any;
  iutProfiles:any;
  selectedCities: any[]=[];
  serverId:any;
  testserver:TestServer[]=[];
  servername:any;
  testCycle:TestCycle = new TestCycle();
  selectedprofiles:any[]=[];
  temp:any[]=[]

  constructor(private router:Router , private formBuilder:FormBuilder,private testCycleService : TestCycleService,
    private activateroute : ActivatedRoute,private testserverService : TestserverService) { 

    this.loggedUserId = localStorage.getItem('loggedUserId');

   this.form = this.formBuilder.group({
    testcycleservername:[],
    selectedProfiles: ['', Validators.required],
   // selectedprofile: this['formBuilder'].array([])
    });

    this.testCycleService.getIUTprofile().subscribe(data =>{
      this.iutProfiles=data.filter((x: { userId: any; }) => x.userId == this.loggedUserId);
      console.log("iutprofiles",data);
      console.log("user profile,",this.iutProfiles);
    });

    this.serverId = Number(this.activateroute.snapshot.paramMap.get('id'));
    this.testserverService.getAllTestServersByUserId().subscribe(data =>{
      this.testserver = data.filter(x=>x.serverId == this.serverId);
      console.log("server data from cycle:" , data);
    this.servername = this.testserver[0].serverName;
  });

  this.testCycleService.getallTestCycle().subscribe(data =>{
    console.log("all test cycles:", data);
  })
}

  ngOnInit(): void {
  };

  gotodetailTestCycle(){
    debugger;
    this.testCycle.userId= this.loggedUserId;
    this.testCycle.testserver_id=this.serverId;
    this.testCycle.status='inprogress';
    this.testCycle.name=this.form.value['testcycleservername'];
    this.selectedprofiles = this.form.value['selectedProfiles'];
    // this.testCycle.IUTprofileIds= this.form.value['selectedProfiles'];
    this.selectedprofiles.forEach(x=> {
      debugger;
       this.temp.push(x.id);
    });
    console.log("test cycle object:", this.testCycle);
    debugger;
    this.testCycle.iut_profile_id=this.temp.toString();
    const dum = JSON.stringify(this.testCycle.iut_profile_id);
    console.log("converted string to json object", dum);
this.testCycleService.addTestCycle(this.testCycle).subscribe(res =>{
  this.testCycle.id=res.id;
  if(this.form.valid){
      this.router.navigate(['/newtestcycle',this.testCycle.id])
    }
  console.log("test cycle add response:", res);
})
    
    
    console.log('formVaLUES',this.form.value)
    
  }
  
  reset(){
     this.form.reset();
     this.router.navigate(['/testserver']);
  }

}
