import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Task } from 'src/app/model/Task';
import { TestCase } from 'src/app/model/TestCase';
import { TestcaseService } from 'src/app/service/testcase.service';

@Component({
  selector: 'app-testcasetable',
  templateUrl: './testcasetable.component.html',
  styleUrls: ['./testcasetable.component.css']
})
export class TestcasetableComponent implements OnInit {
  @Input() testcycle: any;
  @Input() testgroupSelected: any;
  @Input() IUTprofile:any;
  @Output() testGroupevent: EventEmitter<any> = new EventEmitter();

  page: number = 1;
  totalLength: any;
  testCasesFrmSimulator :any;
  testCasesTodb:any;
  testcaseList:any;
  showtestcaseTable:boolean=false;
  date: Date = new Date();
  selectedTestCases: any[] = [];
  showModal:boolean=false;
  content:any;
  title:string='';
  taskResult:any;
  task:Task=new Task;
  loggedUserId:any;
  excutedTaskbyCycle:any;
  currentRunningTask:any;
  testcaseResult:any;
  testcase:TestCase = new TestCase;

  constructor(private testcaseService :TestcaseService) {
    this.loggedUserId = localStorage.getItem('loggedUserId');
   }

  ngOnInit(): void {
  }

  ngOnChanges() {
    console.log("testcycle object frrom parent to child:", this.testcycle);
    console.log("test group selected", this.testgroupSelected);
    if (this.testcycle != undefined) {
      if (this.testcycle != null) {
        this.getCurrentrunningTask(this.testcycle);
      }}
    
    if (this.testgroupSelected != undefined) {
      if (this.testgroupSelected != null) {
       this.onTestGroupSelected(this.testgroupSelected);
      }
    }
  }

   //get test cases
   onTestGroupSelected(id: any) {
    this.testcaseService.getTestCases(id).subscribe(
      (data) => {
        this.testCasesFrmSimulator = data;
        if(this.currentRunningTask.length ==0 || this.currentRunningTask == undefined){
        if(this.testCasesFrmSimulator.length > 0 || this.testCasesFrmSimulator != undefined){
          this.testCasesTodb = this.testCasesFrmSimulator.map((x : any) => {
            x.testcaseid = x.testId
            x.testCycleId = this.testcycle.id,
              x.testGroupId = this.testgroupSelected,
              x.isCheck = false,
              x.status = "",
              x.description = null,
              x.showlogBtn = false,
              x.taskId = null
              this.saveTestCase(x);
          });
        }
        }
        this.getTestcases();
      }
    );
  };

  getTestCaseId(e: any, id: string) {
    if (e.target.checked) {
      this.selectedTestCases.push(id);
    }
    else {
      this.selectedTestCases = this.selectedTestCases.filter(x => x != id)
    }
    console.log("selected testcases : ", this.selectedTestCases);
  }

  //Check if any running Task
  getCurrentrunningTask(testcycle: any) {
    this.testcaseService.getAllExistingTask().subscribe(data => {
      debugger;
      this.excutedTaskbyCycle = data.filter((x: { testcycleId: number; }) => x.testcycleId == this.testcycle.id)
      this.currentRunningTask = this.excutedTaskbyCycle.filter((x: any) => x.status == 'inprogress');
      console.log("existing task list", this.currentRunningTask);
      debugger;
      if (this.currentRunningTask.length != 0) {
        this.testgroupSelected = this.currentRunningTask[0].testGroupId;
        this.testGroupevent.emit(this.testgroupSelected);
        this.onTestGroupSelected(this.testgroupSelected);
      }
    });
  }

  //run testcases
  runTestcase() {
     debugger;
    const iutProfile = {
      "specId": 0,
      "deviceId": '<89076543>',
      "items": [
        {
          "testId": this.selectedTestCases,
          "updates": [
            {
              "name": "IUT_RSP_VERSION",
              "value": this.IUTprofile.IUT_RSP_VERSION
            },
            {
              "name": "IUT_DLOA_URL",
              "value": this.IUTprofile.IUT_DLOA_URL
            },
            {
              "name": "IUT_EUICC_CATEGORY",
              "value": this.IUTprofile.IUT_EUICC_CATEGORY
            },
            {
              "name": "IUT_EUICC_FIRMWARE_VER",
              "value": this.IUTprofile.IUT_EUICC_FIRMWARE_VER
            },
            {
              "name": "IUT_GLOBALPLATFORM_VERSION",
              "value": this.IUTprofile.IUT_GLOBALPLATFORM_VERSION
            },
            {
              "name": "IUT_PLATFORM_LABEL",
              "value": this.IUTprofile.IUT_PLATFORM_LABEL
            },
            {
              "name": "IUT_PP_VERSION",
              "value": this.IUTprofile.IUT_PP_VERSION
            },
            {
              "name": "IUT_SAS_ACREDITATION_NUMBER",
              "value": this.IUTprofile.IUT_SAS_ACREDITATION_NUMBER
            },
            {
              "name": "IUT_TS102241_VERSION",
              "value": this.IUTprofile.IUT_TS102241_VERSION
            },
            {
              "name": "IUT_UICC_CAPABILITY",
              "value": this.IUTprofile.IUT_UICC_CAPABILITY
            },
            {
              "name": "IUT_SIMA_VERSION",
              "value": this.IUTprofile.IUT_SIMA_VERSION
            }
          ]
        }
      ],
      "autoDelete": "true"
    };
    this.runEuicc(iutProfile);
  }

  bulk() {
     
    this.selectedTestCases = [];
    for (let i = 0; i < this.testcaseList.length; i++) {
      this.testcaseList[i].isCheck = this.testcaseList
    }
  }

  showPopup(val: any) {
    this.showModal = true; // Show-Hide Modal Check
    const taskid = 267;
    this.testcaseService.getTesCaseLogs(taskid).subscribe(data => this.content = data);
    this.title = "Log for" + val;    // Dynamic Data
  }

  //hide popup
  hide() {
    this.showModal = false;
  };

//run EUICC test
runEuicc(iutProfile:any){
  this.testcaseService.runeUICCtest(iutProfile).subscribe(
    (data) => {
      console.log("testcase run result:",data[0]);
      this.taskResult = data[0];
        this.task.status = this.taskResult.state;
        this.task.taskId = this.taskResult.id;
        this.task.user_id = this.loggedUserId;
        this.task.testcycle_id = this.testcycle.id;
        this.task.testIds = this.taskResult.testid.toString();
        this.task.deviceId = this.taskResult.deviceid;
        this.task.specid = this.taskResult.specid;
        this.task.testGroupId = this.testgroupSelected;
        this.task.date = this.date;
        this.addTask(this.task);
        this.getTestcaseresult(this.task.taskId);
    }
  )
}

  //save testcases to db
  saveTestCase(testcase:any){
this.testcaseService.saveTestCases(testcase).subscribe(data=>{
  console.log("response after adding testcase",data);
})
  }

  //get testcases from user backend
  getTestcases(){
    this.testcaseService.getTestcaseUserbackend().subscribe(data =>{
      this.testcaseList = data.filter((x:any)=> x.testCycleId == this.testcycle.id);
      console.log("testcases list from userbackend",this.testcaseList);
      if(this.testcaseList.length >0 || this.testcaseList != undefined){
        this.showtestcaseTable = true;
        this.totalLength = this.testcaseList.length;
      }
    })
  }

  //get testcase result from simulator
  getTestcaseresult(taskid:any){
   this.testcaseService.getTestcaseResult(taskid).subscribe(data =>{
    console.log("testcase result fro test simulator",data);
    this.testcaseResult = data;
    this.testcaseResult.forEach((x : any)=>
      this.testcaseService.getTestcasebyId(x.testid).subscribe(data =>{
        this.testcase = data[0];
        this.testcase.status= x.executionstatus;
        this.updatetestCase(this.testcase);
      })
      )
   })
  };

  //update testcase
  updatetestCase(testcase:any){
   this.testcaseService.updateTestcase(testcase).subscribe(data=>{
    console.log("update testcase result",data);
   })
  }

  //Add task
  addTask(task:any){
    this.testcaseService.addTask(task).subscribe(data => {
      console.log("add task result", data);
    });
  }

  //update task


}
