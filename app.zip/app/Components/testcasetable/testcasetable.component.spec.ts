import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestcasetableComponent } from './testcasetable.component';

describe('TestcasetableComponent', () => {
  let component: TestcasetableComponent;
  let fixture: ComponentFixture<TestcasetableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestcasetableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestcasetableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
