import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IUTprofileComponent } from './iutprofile.component';

describe('IUTprofileComponent', () => {
  let component: IUTprofileComponent;
  let fixture: ComponentFixture<IUTprofileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IUTprofileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IUTprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
