import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { eUICC, IUTprofile } from 'src/app/model/IUTprofile';
import { IutprofileService } from 'src/app/service/iutprofile.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-iutprofile',
  templateUrl: './iutprofile.component.html',
  styleUrls: ['./iutprofile.component.css']
})
export class IUTprofileComponent implements OnInit {
  modelTitle:string='';
  isEditmode:boolean=false;
  loggedUserId : any;
  profileList:eUICC= new eUICC();
  iutProfiles:any;
  iutTypes:any;
  IUTform: FormGroup;
  showeUICC:boolean=false;
  showLPA:boolean=false;
  showPlatform:boolean=false;
  profile :any;
  demo: IUTprofile | undefined;
  testCycleList:any;
  status: any;

  constructor( private iutservice : IutprofileService,private userService:UserService,private formBuilder: FormBuilder) { 
    this.loggedUserId = localStorage.getItem('loggedUserId');
    console.log("loggeduser id", this.loggedUserId);
    this.IUTform = this.formBuilder.group({
      userId:[''],
		profile_type_id:[''],
      iut_RSP_VERSION: [''],
        iut_DLOA_URL: [''],
        iut_PP_VERSION: [''],
        iut_EUICC_FIRMWARE_VER: [''],
        iut_GLOBALPLATFORM_VERSION: [''],
        iut_TS102241_VERSION: [''],
        iut_EUICC_CATEGORY: [''],
        iut_PLATFORM_LABEL: [''],
        iut_SAS_ACREDITATION_NUMBER: [''],
        iut_UICC_CAPABILITY: [''],
        iut_SIMA_VERSION: [''],
        iUTProfile: this.formBuilder.group({
          id:[''],
          userId : [''],
          profileTypeId : [''],
          iutName: [''],
          deviceId : [''],
          specId : [''],
          status : [''],
          autoDelete : ['']
        })
    });
    this.iutservice.getiutTypes().subscribe(res =>{
      this.iutTypes=res;
      console.log("iut types:",res);
    });

    this.iutservice.getAllIutProfiles().subscribe(data =>{
      console.log("all iut profiles:", data);
      this.iutProfiles = data.filter((x: { userId: any; })=> x.userId == this.loggedUserId);
      this.iutProfiles.forEach((x: {
        iUTProfile: any;
        status: string;
        id: any;
      }) => {
        debugger;
        this.iutservice.getallTestCycle().subscribe(
          (data) => {
            this.testCycleList = data.filter((i: any) => i.iut_profile_id == x.id);
            if (this.testCycleList.length != 0) {
              // this.isAvailable = "Available";
              x.iUTProfile.status = "Busy";
              x.status = "Busy";
              this.status = "Busy"
            }
            else {
              x.status = "Available";
              x.iUTProfile.status = "Available";
              this.status = "Available"
            }
            console.log("testcycle based on test serverid status", this.iutProfiles);
            this.iutservice.updateIUTprofile(x, x.id).subscribe(data => {
              console.log("update testserver result:", data);
            })
          }
        );
        

      })

      console.log("profile list:", this.iutProfiles);
    })
  }

  ngOnInit(): void {
    // this.onchangeIutType();
    
  }


  openModel(){
    debugger;
   this.IUTform.reset();

    const model = document.getElementById("myModal");
    
    if (model!= null){
      model.style.display="block";

    }
    if(this.isEditmode){
      this.IUTform.controls['iut_RSP_VERSION'].disable();
    }
  }
  closeModel(){
    const model = document.getElementById("myModal");
    if (model!= null){
      model.style.display="none";

    }
    this.isEditmode=false;
  }

  addProfile(){
debugger;
console.log("add form values",this.IUTform.value);
if(!this.isEditmode){
  this.IUTform.value.userId = this.loggedUserId;
this.IUTform.value.iUTProfile.userId = this.loggedUserId;
this.IUTform.value['profile_type_id'] = this.IUTform.value.iUTProfile.profileTypeId;
this.iutservice.addIUTprofile(this.IUTform.value).subscribe(data =>{
  console.log("adding iut pprofile", data.text);
  alert('profile added successfully');
})
}
if(this.isEditmode){
  //this.IUTform.getRawValue().iUTProfile.userId = this.loggedUserId;
  this.iutservice.updateIUTprofile(this.IUTform.getRawValue(),this.IUTform.getRawValue().iUTProfile.id).subscribe(data =>{
    console.log("adding iut pprofile", data.text);
    alert('profile added successfully');
    //this.onpopSubmit();
  })
}
const model = document.getElementById("myModal");
    if (model!= null){
      model.style.display="none";
    }

  }

  onIUTtypeSelected(id:any){

if(id=='1'){
  this.showeUICC = true;
  this.modelTitle = 'eUICC'
}
else {
  this.showeUICC=false;
}
if(id=='2'){
  this.showPlatform = true;
  this.modelTitle = 'Platform'
}
else {
  this.showPlatform=false;
}
if(id=='3'){
  this.showLPA = true;
  this.modelTitle = 'LPA'
}
else {
  this.showLPA=false;
}
  }

  onpopSubmit(){
    debugger;
// this.iutservice.addIUTprofile(this.iutProfile).subscribe(data =>{
//   console.log("adding iut pprofile", data);
//})
    const model = document.getElementById("myModal");
    if (model!= null){
      model.style.display="none";
    }
   // window.location.reload();
  }
  deleteProfile(id:any){
    debugger;
   this.iutservice.deleteiutProfile(id).subscribe(result => {
    alert(result);
    console.log("delete iut profile:",result);
   }
    
    )
    window.location.reload();
  }
  editProfile(prof:any){
    debugger;
    this.isEditmode=true;
    this.profile= this.iutProfiles.filter((x: { id: any; })=> x.id == prof.id)[0];
    this.IUTform.patchValue({
      iut_RSP_VERSION:this.profile.iut_RSP_VERSION,
        iut_DLOA_URL: this.profile.iut_DLOA_URL,
        iut_PP_VERSION: this.profile.iut_PP_VERSION,
        iut_EUICC_FIRMWARE_VER: this.profile.iut_EUICC_FIRMWARE_VER,
        iut_GLOBALPLATFORM_VERSION: this.profile.iut_GLOBALPLATFORM_VERSION,
        iut_TS102241_VERSION:this.profile.iut_TS102241_VERSION,
        iut_EUICC_CATEGORY: this.profile.iut_EUICC_CATEGORY,
        iut_PLATFORM_LABEL: this.profile.iut_PLATFORM_LABEL,
        iut_SAS_ACREDITATION_NUMBER: this.profile.iut_SAS_ACREDITATION_NUMBER,
        iut_UICC_CAPABILITY: this.profile.iut_UICC_CAPABILITY,
        iut_SIMA_VERSION: this.profile.iut_SIMA_VERSION,
        userId:this.profile.userId,
      profile_type_id:this.profile.profile_type_id,
        iUTProfile: {
          id:this.profile.iUTProfile?.id,
          userId : this.profile.iUTProfile?.userId,
          profileTypeId : this.profile.iUTProfile?.profileTypeId,
          iutName: this.profile.iUTProfile?.iutName,
          deviceId : this.profile.iUTProfile?.deviceId,
          specId : this.profile.iUTProfile?.specId,
          status : this.profile.iUTProfile?.status,
          autoDelete : this.profile.iUTProfile?.autoDelete
        }
    });
    if(this.isEditmode){
      //this.iutProfile.controls['profileTypeId'].disable();
      this.IUTform.controls['iUTProfile'].disable();
      this.IUTform.getRawValue();
    }
    else{
      this.IUTform.controls['iUTProfile'].enable();
    }
    
    const model = document.getElementById("myModal");
       if (model!= null){
      model.style.display="block";
    }
     
     
  }

  onchangeIutType(){
        
        // this.profileList.Device_id = '';
        // this.profileList. Rsp_Version='';
        // this.profileList.Imei_Number='';
        // this.profileList.Status='';
       this.profileList = new eUICC() ;
  debugger;
    if(this.profileList.iUTProfile?.profileTypeId == 1){
      this.modelTitle = 'eUICC'

    }
    else if(this.profileList.iUTProfile?.profileTypeId  == 2){
      this.modelTitle = 'LPA'

    }
    else{
      this.modelTitle = 'Platform'
   }

  }

}
