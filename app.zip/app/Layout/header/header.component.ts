import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  loogedUser : any;
  userDisplayName:any;
  constructor(private router: Router,private userService:UserService) { 
    //this.user=this.userService.setUser();
  }

  ngOnInit(): void {
    this.loogedUser = localStorage.getItem('loggedUser');
  }
  logout(){
    this.userService.logout();
      
    
  }

}
