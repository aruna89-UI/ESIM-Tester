import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  errorMessage : string ='';
  isloginSuccess:boolean = false;
loginObj:any={
  userName:'',
  userPassword:''
}
  constructor(private userService:UserService,private router: Router) { }

  ngOnInit(): void {
  }

  onLogin(){
   debugger;
   this.userService.loginUser(this.loginObj).subscribe(data =>{
    if(data !=null){
      this.isloginSuccess = true;
      console.log("user data",data);
      this.router.navigate(['/dashboard']);
    }
    else{
      this.isloginSuccess=false;
    }
   })
  
  }
}

