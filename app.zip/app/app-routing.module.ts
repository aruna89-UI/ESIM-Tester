import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './Components/home/home.component';
import { IUTprofileComponent } from './Components/iutprofile/iutprofile.component';
import { NewtestcycleComponent } from './Components/newtestcycle/newtestcycle.component';
import { RegisterComponent } from './Components/register/register.component';
import { RegistersuccessComponent } from './Components/registersuccess/registersuccess.component';
import { TestCycleComponent } from './Components/test-cycle/test-cycle.component';
import { TestReportComponent } from './Components/test-report/test-report.component';
import { TestServerComponent } from './Components/test-server/test-server.component';
//import { HomeComponent } from './Layout/home/home.component';
import { LoginComponent } from './Layout/login/login.component';

const routes: Routes = [
  {
    path:'',
    component:RegisterComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'register',
    component:RegisterComponent
  },
  {
    path:'registersuccesful',
    component:RegistersuccessComponent,
    // children:[]
  },
{
  path:'dashboard',
  component:HomeComponent,
  // children:[]
},
{path : 'testserver', component : TestServerComponent},
    {path : 'IUTProfile', component: IUTprofileComponent},
    {path : 'testreport', component: TestReportComponent},
    // {path : 'testcycle' ,component:TestCycleComponent},
    {path : 'testcycle/:id' ,component:TestCycleComponent},
    {path : 'newtestcycle' ,component:NewtestcycleComponent},
    {path : 'newtestcycle/:id' ,component:NewtestcycleComponent}
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
